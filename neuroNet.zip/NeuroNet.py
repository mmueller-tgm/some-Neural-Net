import json
import Layer
import Node

class NeuroNet():
    def __init__(self, *params):
        self.__create_net(params)

    def __create_net(self, params):
        i = len(params)
        if i < 4:
            print("Too few Arguments")
            exit(1)
        self.layers = []
        self.hl_nodes = []
        self.learn_rate = 0
        print(params)
        i = len(params)
        self.learn_rate = params[i - 1]
        for j, o in enumerate(params):
            if j != i - 1:
                self.hl_nodes.append(o)

        self.layers.append(Layer.EmptyLayer())
        for i in range(0, len(self.hl_nodes)):
            self.layers.append(Layer.Layer(self.hl_nodes[i], self.layers[i]))

    def export_net(self, file):
        f = open(file, 'w+')
        j = json.dumps(self, cls=MyNetEncoder, sort_keys=True, indent=4)
        f.write(j)
        print("Exported net: \"%s\"" % (file))

    def import_net(self, file):
        f = open(file, 'r')
        j = json.load(f)
        print("Importing net: \"%s\" (%s)" % (file, j['settings']))
        self.__create_net(tuple(j['settings']))
        for h, o in enumerate(self.layers):
            for i, p in enumerate(o.nodes):
                p.d = j['layers'][h][i]['bias']
                p.weight_j = j['layers'][h][i]['wji']

    def train(self, file, amt):
        f = open(file)
        train = json.load(f)
        print("Training net with \"%s\" for %i times" % (file, amt))
        for i in range(0, amt):
            for j in train:
                input = j[0]
                target = j[1]
                out = []
                err = []

                out = self.evaluate(input)
                for k in range(0, len(target)):
                    e = out[k]*(1-out[k])*(target[k]-out[k])
                    self.layers[len(self.layers)-1].nodes[k].err = e
                    err.append(e)

                #print("gerneration:%i, in:%s, target:%s, out:%s, error:%s, total error:%s" %
                # (i, input, target, out, err, sum(err)))

                self.back_propergate()
        print("Finished training with \"%s\" for %i times" % (file, amt))


    def back_propergate(self):
        i = len(self.layers)-2
        while i > 0: #every layer except the last one, startig from the second to last one
            for k, o in enumerate(self.layers[i].nodes): #for every node in the layer
                # j: number of the node
                # o: node object
                e = 0   # error for the node
                for v in self.layers[i+1].nodes: # for every node in the next layer
                    e += v.calc_err(k)
                o.err = e * (o.value * (1-o.value))

                for v in self.layers[i+1].nodes:
                    v.weight_j[k] += self.learn_rate * v.err * o.value

                o.d += self.learn_rate * o.err
            i -= 1
        for i in self.layers[len(self.layers)-1].nodes:
            i.d += self.learn_rate * i.err



    def evaluate(self, *args):
        for i, o in enumerate(self.layers[1].nodes):
            o.value = args[0][i]
        for i in range(2, len(self.layers)):
            self.layers[i].evaluate()

        lst = []
        for o in self.layers[len(self.layers)-1].nodes:
            lst.append(o.value)
        return lst

    def __str__(self):
        return "nodes:%s r:%f" % (self.hl_nodes, self.learn_rate)


class MyNetEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Node.Node):
            return{"bias": o.d, "wji":o.weight_j}
        if isinstance(o, Layer.Layer):
            return o.nodes
        if isinstance(o, Layer.EmptyLayer):
            return
        if isinstance(o, NeuroNet):
            sett = o.hl_nodes
            sett.append(o.learn_rate)
            return{"settings":sett, "layers":o.layers}


if __name__ == "__main__":
    n = NeuroNet(2, 3, 1, 0.9)
    n.train("xor.json", 10000)
    print("[1, 1] equals:%s" % n.evaluate([1, 1]))
    n.export_net("xor_net.json")
    n.train("or.json", 1000)
    print("[1, 1] equals:%s" % n.evaluate([1, 1]))
    n.import_net("xor_net.json")
    print("[1, 1] equals:%s" % n.evaluate([1, 1]))
    i=1




















